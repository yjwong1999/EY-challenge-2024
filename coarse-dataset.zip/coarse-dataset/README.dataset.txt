# new > 2024-02-25 1:54am
https://universe.roboflow.com/edge-4k8xw/new-8wmww

Provided by a Roboflow user
License: CC BY 4.0

