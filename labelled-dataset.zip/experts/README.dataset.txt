# extra-fine-grained > 2024-03-05 9:37pm
https://universe.roboflow.com/edge-4k8xw/extra-fine-grained

Provided by a Roboflow user
License: CC BY 4.0

